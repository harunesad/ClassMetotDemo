﻿using System;

namespace ClassMetotDemo
{
    class Program
    {
        static void Main(string[] args)
        { 
        Musteri Musteri1 = new Musteri();
          
            Musteri1.MusteriAd = "Mert";
            Musteri1.MusteriSoyad = "Tekin";
            Musteri1.MusteriID = 587952;
            Musteri1.MusteriGmail ="Mert@gmail.com";

            Musteri Musteri2 = new Musteri();

            Musteri2.MusteriAd = "Samet";
            Musteri2.MusteriSoyad = "Yılmaz";
            Musteri2.MusteriID = 175235;
            Musteri2.MusteriGmail ="Samet@gmail.com";

            Musteri Musteri3 = new Musteri();

            Musteri3.MusteriAd = "Eray";
            Musteri3.MusteriSoyad = "Turan";
            Musteri3.MusteriID = 741526;
            Musteri3.MusteriGmail ="Eray@gmail.com";

            Musteri[] musteri = new Musteri[] {Musteri1,Musteri2,Musteri3 };

            foreach (var m in musteri)
            {
                Console.WriteLine("İSİM : " + m.MusteriAd);
                Console.WriteLine("SOYAD : " + m.MusteriSoyad);
                Console.WriteLine("ID : " + m.MusteriID);
                Console.WriteLine("Gmail : " + m.MusteriGmail);
            }

            MusteriManager musteriManager = new MusteriManager();
            musteriManager.Ekle("Ahmet","Koca",454565,"Ahmet@gmail.com");
            musteriManager.Ekle("Eda","Özgü",156585,"Eda@gmail.com");
            musteriManager.Ekle("Tolga","Andıç",178952,"Tolga@gmail.com");
        }
    }
}
