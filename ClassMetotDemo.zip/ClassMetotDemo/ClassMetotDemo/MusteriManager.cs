﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassMetotDemo
{
    class MusteriManager
    {
        public  void Ekle(string MusteriAd, string MusteriSoyad, int MusteriID, string MusteriGmail)
        {
            Console.WriteLine("İsim eklendi : " + MusteriAd);
            Console.WriteLine("Soyad eklendi : " + MusteriSoyad);
            Console.WriteLine("ID eklendi : " + MusteriID);
            Console.WriteLine("Gmail eklendi : " + MusteriGmail);
        } 
    }
}
